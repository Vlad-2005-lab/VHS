from flask_login import LoginManager, login_user, login_required, logout_user, current_user
import datetime
from flask import Flask, render_template, make_response, abort
from flask_wtf import FlaskForm
from werkzeug.utils import redirect
from wtforms import PasswordField, BooleanField, SubmitField, StringField, TextAreaField, IntegerField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired
from smtplib import SMTP
from random import randint
import os

from Social.data.users import User
from Social.data.news import News
from Social.data.sms import Sms
from Social.data import db_session
from flask import request

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)

user = User()
number = 0


def parse(text):
    new_text = ''
    len_t = len(text)
    while len_t > 50:
        new_text += text[: 50]
        new_text += '\n'
        len_t -= 50
        text = text[50:]
    new_text += text
    return new_text


def mail(mail):
    global number
    number = randint(1000, 9999)
    smtpObj = SMTP('smtp.gmail.com', port=587)
    smtpObj.starttls()
    smtpObj.login('vns.social.networks@gmail.com', 'dkflxvje`,jr')
    smtpObj.sendmail("vns.social.networks@gmail.com", mail, str(number))
    smtpObj.quit()


def correct_mail(mail):
    mail = str(mail)
    if '@' in mail and mail.count('@') == 1 and mail[0] != '@' and mail[mail.rfind('@'):].count('.') == 1:
        return True
    return False


class Perepiska(FlaskForm):
    search = StringField('Написать', validators=[DataRequired()])
    submit = SubmitField('Отправить')


class RegisterForm(FlaskForm):
    username = EmailField('Login/email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    r_password = PasswordField('Repeat password', validators=[DataRequired()])
    surname = StringField('Surname', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    age = IntegerField('Age', validators=[DataRequired()])
    submit = SubmitField('Submit')


class Friends_form(FlaskForm):
    search = StringField('Поиск', validators=[DataRequired()])
    submit = SubmitField('Поиск')


class NewsForm(FlaskForm):
    title = StringField('Заголовок', validators=[DataRequired()])
    content = TextAreaField("Содержание")
    is_private = BooleanField("Личное")
    submit = SubmitField('Добавить')


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class MS(FlaskForm):
    submit = SubmitField('Начать разговор')
    write = SubmitField('Написать')
    begin = SubmitField('Начать диалог')


class code_verefication(FlaskForm):
    code = IntegerField('Введите код на который пришёл на введённую почту')
    submit = SubmitField('Подтвердить')


@login_manager.user_loader
def load_user(user_id):
    session = db_session.create_session()
    return session.query(User).get(user_id)


@app.route('/')
def enter():
    return redirect('/login')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        user = session.query(User).filter(User.email == form.email.data).first()
        if user and user.hashed_password == form.password.data:
            login_user(user, remember=form.remember_me.data)
            return redirect(f"/main/{current_user.id}")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/register', methods=['GET', 'POST'])
def register():
    global user
    form = RegisterForm()
    session = db_session.create_session()
    sp = []
    for el in session.query(User).all():
        sp.append(el.email)
    if form.validate_on_submit() and form.password.data == form.r_password.data and correct_mail(form.username.data) \
            and form.username.data not in sp:
        user.name = form.name.data
        user.surname = form.surname.data
        user.email = form.username.data
        user.hashed_password = form.password.data
        user.age = form.age.data
        user.modified_data = datetime.datetime.now()
        mail(user.email)
        return redirect('/mail')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/main/<int:id>', methods=['GET', 'POST'])
def main(id):
    # global number, user
    # form = code_verefication()
    # if form.validate_on_submit:
    #     if str(number) == str(form.code.data) and str(number) != '0':
    #         session = db_session.create_session()
    #         session.add(user)
    #         session.commit()
    #         return redirect('/login')
    #     return render_template('mail.html', title='Проверка почты', form=form, message='Неверный код')

    if id == current_user.id:
        session = db_session.create_session()
        sp_news = []
        for el in session.query(News).all():
            if str(id) == str(el.user_id):
                sp_news.append(el)
        return render_template('main.html', sp_news=list(reversed(sp_news)))
    else:
        abort(404)


@app.route('/edit_news/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_news(id):
    form = NewsForm()
    if request.method == "GET":
        session = db_session.create_session()
        news = session.query(News).filter(News.id == id,
                                          News.user == current_user).first()
        if news:
            form.title.data = news.title
            form.content.data = news.content
        else:
            abort(404)
    if form.validate_on_submit():
        session = db_session.create_session()
        news = session.query(News).filter(News.id == id,
                                          News.user == current_user).first()
        if news:
            news.title = form.title.data
            news.content = form.content.data
            news.is_private = form.is_private.data
            session.commit()
            return redirect('/main/' + str(current_user.id))
        else:
            abort(404)
    return render_template('news.html', title='Редактирование новости', form=form)


@app.route('/news_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def news_delete(id):
    session = db_session.create_session()
    news = session.query(News).filter(News.id == id,
                                      News.user == current_user).first()
    if news:
        session.delete(news)
        session.commit()
    else:
        abort(404)
    return redirect('/main/' + str(current_user.id))


@app.route('/news_fr/<int:id>', methods=['GET', 'POST'])
def news(id):
    session = db_session.create_session()
    sp_news = []
    sp_autors = []
    for el in session.query(News):
        if str(el.user_id) in str(current_user.friends).split(', ') or not el.is_private:
            sp_news.append(el)
            for ell in session.query(User):
                if str(ell.id) == str(el.user_id):
                    sp_autors.append(ell)
    return render_template('news_fr.html', sp_news=list(reversed(sp_news)), sp_autors=list(reversed(sp_autors)))


@app.route('/perepiska/<int:id>', methods=['GET', 'POST'])
def perepiska(id):
    form = Perepiska()
    if os.path.exists(f'sms/{current_user.id}-{id}.txt'):
        file = open(f'sms/{current_user.id}-{id}.txt', mode='rt', encoding='UTF-8')
    else:
        file = open(f'sms/{current_user.id}-{id}.txt', mode='tw', encoding='UTF-8')
        file = open(f'sms/{id}-{current_user.id}.txt', mode='tw', encoding='UTF-8')
        file = open(f'sms/{current_user.id}-{id}.txt', mode='rt', encoding='UTF-8')
    sp_d = file.readlines()
    if form.submit.data and form.search.data != '':
        file = open(f'sms/{current_user.id}-{id}.txt', mode='w', encoding='UTF-8')
        file1 = open(f'sms/{id}-{current_user.id}.txt', mode='tw', encoding='UTF-8')
        text = form.search.data
        text = parse(text)
        for i in sp_d:
            print(i, file=file)
            print(i, file=file1)
        session = db_session.create_session()
        for i in session.query(User).all():
            if i.id == current_user.id:
                print(i.name + ' ' + i.surname, file=file)
                print(i.name + ' ' + i.surname, file=file1)
                break
        print(text, file=file)
        print(text, file=file1)
        session = db_session.create_session()
        for i in session.query(Sms).all():
            if i.user_id == current_user.id and i.id_friend == id:
                i.name = f'sms/{current_user.id}-{id}.txt'
                session.commit()
                break
        return redirect(f'/perepiska/{id}')
    return render_template('perepiska.html', form=form, sp_d=sp_d)


@app.route('/begin/<int:id>', methods=['GET', 'POST'])
def begin(id):
    form = MS()
    session = db_session.create_session()
    sp_id = list(map(int, str(current_user.friends).split(', ')))
    sp_d = []
    for i in session.query(User).all():
        if i.id in sp_id:
            sp_d.append([str(i.name) + ' ' + str(i.surname), i.id])
    return render_template('begin.html', form=form, sp_d=sp_d)


@app.route('/sms/<int:id>', methods=['GET', 'POST'])
def sms(id):
    form = MS()
    session = db_session.create_session()
    sp_id = list(map(int, str(current_user.friends).split(', ')))
    sp_d = []
    for i in session.query(User).all():
        if i.id in sp_id and os.path.exists(f'sms/{current_user.id}-{i.id}.txt'):
            sp_d.append([str(i.name) + ' ' + str(i.surname), i.id])
    s = [len(sp_d)] + sp_d
    sp_d = s
    if form.submit.data:
        sp_d = []
        for i in session.query(User).all():
            if i.id in sp_id:
                sp_d.append((str(i.name) + ' ' + str(i.surname)))
        return redirect(f'/begin/{id}')
    elif form.write.data:
        return redirect(f'/perepiska/{id}')
    return render_template('sms.html', form=form, sp_d=sp_d)

@app.route('/f_profile/<int:id>', methods=['GET', 'POST'])
def f_profile(id):
    session = db_session.create_session()
    if str(current_user.id) in str(session.query(User).filter(int(id) == User.id).first().friends).split(', '):
        session = db_session.create_session()
        sp_news = []
        maaaaaan = session.query(User).filter(int(id) == User.id).first()
        for el in session.query(News).all():
            if str(id) == str(el.user_id):
                sp_news.append(el)
        return render_template('f_main.html', sp_news=sp_news, maaaaaan=maaaaaan)
    else:
        abort(404)


@app.route('/friends/<int:id>', methods=['GET', 'POST'])
def friends(id):
    form = Friends_form()
    session = db_session.create_session()
    sp_friends = []
    for el in session.query(User).all():
        if str(current_user.id) in str(el.friends).split(', '):
            sp_friends.append(el)
    if form.submit.data:
        return redirect(f'/search/{form.search.data}')
    return render_template('your_friends.html', form=form, sp_friends=sp_friends)


@app.route('/append_friend/<int:id>', methods=['GET', 'POST'])
def append_friend(id):
    session = db_session.create_session()
    user = session.query(User).filter(User.id == current_user.id).first()
    user.friends = str(user.friends) + ', ' + str(id)
    session.commit()
    session = db_session.create_session()
    user = session.query(User).filter(User.id == id).first()
    user.friends = str(user.friends) + ', ' + str(current_user.id)
    session.commit()
    return redirect(f'/friends/{current_user.id}')


@app.route('/search/<string:s>', methods=['GET', 'POST'])
def search_friends(s):
    form = Friends_form()
    s = s.lower()
    session = db_session.create_session()
    sp_p = []
    for el in session.query(User).all():
        if (s in (el.name + el.surname).lower() or s in (el.surname + el.name).lower()) and str(el.id) not in str(
                current_user.friends).split(', ') and el.id != current_user.id:
            sp_p.append(el)
    if form.submit.data:
        return redirect(f'/search/{form.search.data}')
    return render_template('serch_friends.html', sp_p=sp_p, form=form)


@app.route('/friends_delete/<int:id>', methods=['GET', 'POST'])
def friends_delete(id):
    session = db_session.create_session()
    st = str(session.query(User).filter(User.id == current_user.id).first().friends).split(', ')
    for i in range(len(st)):
        if st[i] == str(id):
            del st[i]
            break
    user = session.query(User).filter(User.id == current_user.id).first()
    user.friends = ', '.join(st)
    session.commit()
    session = db_session.create_session()
    st = str(session.query(User).filter(User.id == id).first().friends).split(', ')
    for el in session.query(User).all():
        if str(el.id) == str(id):
            user = el
            break
    for i in range(len(st)):
        if st[i] == str(current_user.id):
            del st[i]
            break
    user.friends = ', '.join(st)
    session.commit()
    return redirect(f'/friends/{current_user.id}')


@app.route('/add_news/<int:id>', methods=['GET', 'POST'])
def add_news(id):
    form = NewsForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        news = News()
        news.title = form.title.data
        news.content = form.content.data
        news.is_private = form.is_private.data
        news.user_id = current_user.id
        # current_user.news.append(news)
        # session.merge(current_user)
        session.add(news)
        session.commit()
        return redirect('/main/' + str(current_user.id))
    return render_template('news.html', title='Добавление новости',
                           form=form)


@app.route('/mail', methods=['GET', 'POST'])
def mail_verification():
    global number, user
    form = code_verefication()
    if form.validate_on_submit:
        if str(number) == str(form.code.data) and str(number) != '0':
            session = db_session.create_session()
            session.add(user)
            session.commit()
            return redirect('/login')
        return render_template('mail.html', title='Проверка почты', form=form)
    return render_template('mail.html', title='Проверка почты', form=form)


def Main():
    db_session.global_init("db/blog.sqlite")
    app.run(port=8080, host='192.168.1.6')


if __name__ == '__main__':
    Main()
