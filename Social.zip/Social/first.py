from flask_login import LoginManager, login_user, login_required, logout_user, current_user
import datetime
from flask import Flask, render_template, make_response, abort
from flask_wtf import FlaskForm
from werkzeug.utils import redirect
from wtforms import PasswordField, BooleanField, SubmitField, StringField, TextAreaField, IntegerField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired
from smtplib import SMTP
from random import randint

from Social.data.users import User
from Social.data.news import News
from Social.data import db_session
from flask import request

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)

user = User()
number = 0


def mail(mail):
    global number
    number = randint(1000, 9999)
    smtpObj = SMTP('smtp.gmail.com', port=587)
    smtpObj.starttls()
    smtpObj.login('vns.social.networks@gmail.com', 'dkflxvje`,jr')
    smtpObj.sendmail("vns.social.networks@gmail.com", mail, str(number))
    smtpObj.quit()


def correct_mail(mail):
    mail = str(mail)
    if '@' in mail and mail.count('@') == 1 and mail[0] != '@' and mail[mail.rfind('@'):].count('.') == 1:
        return True
    return False


class RegisterForm(FlaskForm):
    username = EmailField('Login/email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    r_password = PasswordField('Repeat password', validators=[DataRequired()])
    surname = StringField('Surname', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    age = IntegerField('Age', validators=[DataRequired()])
    submit = SubmitField('Submit')


class NewsForm(FlaskForm):
    title = StringField('Заголовок', validators=[DataRequired()])
    content = TextAreaField("Содержание")
    is_private = BooleanField("Личное")
    submit = SubmitField('Добавить')


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class code_verefication(FlaskForm):
    code = IntegerField('Введите код на который пришёл на введённую почту')
    submit = SubmitField('Подтвердить')


@login_manager.user_loader
def load_user(user_id):
    session = db_session.create_session()
    return session.query(User).get(user_id)


@app.route('/')
def enter():
    return redirect('/login')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        user = session.query(User).filter(User.email == form.email.data).first()
        if user and user.hashed_password == form.password.data:
            login_user(user, remember=form.remember_me.data)
            return redirect(f"/main/{current_user.id}")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/register', methods=['GET', 'POST'])
def register():
    global user
    form = RegisterForm()
    session = db_session.create_session()
    sp = []
    for el in session.query(User).all():
        sp.append(el.email)
    if form.validate_on_submit() and form.password.data == form.r_password.data and correct_mail(form.username.data) \
            and form.username.data not in sp:
        user.name = form.name.data
        user.surname = form.surname.data
        user.email = form.username.data
        user.hashed_password = form.password.data
        user.age = form.age.data
        user.modified_data = datetime.datetime.now()
        mail(user.email)
        print('aaa')
        return redirect('/mail')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/main/<int:id>', methods=['GET', 'POST'])
def main(id):
    # global number, user
    # form = code_verefication()
    # if form.validate_on_submit:
    #     if str(number) == str(form.code.data) and str(number) != '0':
    #         session = db_session.create_session()
    #         session.add(user)
    #         session.commit()
    #         return redirect('/login')
    #     return render_template('mail.html', title='Проверка почты', form=form, message='Неверный код')
    print(id, current_user.id)
    if id == current_user.id:
        session = db_session.create_session()
        sp_news = []
        for el in session.query(News).all():
            if str(id) == str(el.user_id):
                sp_news.append(el)
        return render_template('main.html', sp_news=sp_news)
    else:
        abort(404)


@app.route('/edit_news/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_news(id):
    form = NewsForm()
    if request.method == "GET":
        session = db_session.create_session()
        news = session.query(News).filter(News.id == id,
                                          News.user == current_user).first()
        if news:
            form.title.data = news.title
            form.content.data = news.content
        else:
            abort(404)
    if form.validate_on_submit():
        session = db_session.create_session()
        news = session.query(News).filter(News.id == id,
                                          News.user == current_user).first()
        if news:
            news.title = form.title.data
            news.content = form.content.data
            news.is_private = form.is_private.data
            session.commit()
            return redirect('/main/' + str(current_user.id))
        else:
            abort(404)
    return render_template('news.html', title='Редактирование новости', form=form)


@app.route('/news_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def news_delete(id):
    session = db_session.create_session()
    news = session.query(News).filter(News.id == id,
                                      News.user == current_user).first()
    if news:
        session.delete(news)
        session.commit()
    else:
        abort(404)
    return redirect('/main/' + str(current_user.id))


@app.route('/news_fr/<int:id>', methods=['GET', 'POST'])
def news(id):
    return render_template('news_fr.html')


@app.route('/sms/<int:id>', methods=['GET', 'POST'])
def sms(id):
    return render_template('sms.html')


@app.route('/friends/<int:id>', methods=['GET', 'POST'])
def friends(id):
    return render_template('friends.html')


@app.route('/add_news/<int:id>', methods=['GET', 'POST'])
def add_news(id):
    form = NewsForm()
    if form.validate_on_submit():
        session = db_session.create_session()
        news = News()
        news.title = form.title.data
        news.content = form.content.data
        news.is_private = form.is_private.data
        news.user_id = current_user.id
        # current_user.news.append(news)
        # session.merge(current_user)
        session.add(news)
        session.commit()
        return redirect('/main/' + str(current_user.id))
    return render_template('news.html', title='Добавление новости',
                           form=form)


@app.route('/mail', methods=['GET', 'POST'])
def mail_verification():
    global number, user
    form = code_verefication()
    if form.validate_on_submit:
        if str(number) == str(form.code.data) and str(number) != '0':
            session = db_session.create_session()
            session.add(user)
            session.commit()
            return redirect('/login')
        return render_template('mail.html', title='Проверка почты', form=form)
    return render_template('mail.html', title='Проверка почты', form=form)


def Main():
    db_session.global_init("db/blog.sqlite")
    app.run(port=8080, host='192.168.1.8')


if __name__ == '__main__':
    Main()
